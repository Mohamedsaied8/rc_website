

<?php $__env->startSection('title', 'Site Settings'); ?>
<?php $__env->startSection('page-title', 'Site Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 style="margin: 0; color: #1e293b;">Contact Information & Site Settings</h2>
    </div>

    <?php if(session('success')): ?>
        <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <thead style="background: #f8fafc;">
                <tr>
                    <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">Setting</th>
                    <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">Value</th>
                    <th style="padding: 1rem; text-align: center; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="border-bottom: 1px solid #f3f4f6;">
                    <td style="padding: 1rem; color: #1f2937; font-weight: 500;">
                        <div style="display: flex; flex-direction: column;">
                            <span style="font-weight: 600;"><?php echo e(ucwords(str_replace('_', ' ', $setting->key))); ?></span>
                            <?php if($setting->description): ?>
                                <small style="color: #6b7280; font-size: 0.875rem;"><?php echo e($setting->description); ?></small>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td style="padding: 1rem; color: #6b7280; max-width: 300px; word-wrap: break-word;">
                        <?php if($setting->type === 'url'): ?>
                            <a href="<?php echo e($setting->value); ?>" target="_blank" style="color: #2dd4bf; text-decoration: none;"><?php echo e($setting->value); ?></a>
                        <?php elseif($setting->type === 'email'): ?>
                            <a href="mailto:<?php echo e($setting->value); ?>" style="color: #2dd4bf; text-decoration: none;"><?php echo e($setting->value); ?></a>
                        <?php elseif($setting->type === 'phone'): ?>
                            <a href="tel:<?php echo e($setting->value); ?>" style="color: #2dd4bf; text-decoration: none;"><?php echo e($setting->value); ?></a>
                        <?php else: ?>
                            <?php echo e($setting->value); ?>

                        <?php endif; ?>
                    </td>
                    <td style="padding: 1rem; text-align: center;">
                        <a href="<?php echo e(route('admin.settings.edit', $setting)); ?>" class="btn-secondary" style="padding: 0.5rem 1rem; font-size: 0.875rem;">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" style="padding: 2rem; text-align: center; color: #6b7280;">
                        No settings found.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>