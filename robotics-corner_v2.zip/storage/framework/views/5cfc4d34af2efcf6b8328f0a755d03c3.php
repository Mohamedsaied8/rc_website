

<?php $__env->startSection('title', $course['title'] . ' - Robotics Corner'); ?>
<?php $__env->startSection('description', $course['description']); ?>

<?php $__env->startSection('content'); ?>
<section class="hero">
    <div class="container">
        <h1 class="section-title"><?php echo e($course['title']); ?></h1>
        <p class="section-subtitle"><?php echo e($course['description']); ?></p>
        
        <?php if(isset($course['video'])): ?>
        <div class="course-video" style="margin-top: 2rem; max-width: 800px;">
            <iframe width="100%" height="400" style="min-height: 300px; border: 0; border-radius: 12px" src="<?php echo e($course['video']); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        <?php endif; ?>
    </div>
</section>

<div class="container" style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; padding: 2rem 0;">
    <main class="panel" style="background: #fff; border: 1px solid #e2e8f0; border-radius: 18px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); padding: 1.5rem;">
        <h2 style="margin-bottom: 0.5rem">Overview</h2>
        <p class="subtitle" style="color: #64748b; margin-bottom: 1.5rem;"><?php echo e($course['overview']); ?></p>
        
        <h3 style="margin: 1rem 0 0.5rem">What You'll Learn</h3>
        <ul class="list" style="display: grid; gap: 0.5rem; color: #475569;">
            <?php $__currentLoopData = $course['what_youll_learn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>• <?php echo e($item); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
        <h3 style="margin: 1.5rem 0 0.5rem">Projects</h3>
        <ul class="list" style="display: grid; gap: 0.5rem; color: #475569;">
            <?php $__currentLoopData = $course['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>• <?php echo e($project); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
        <h3 style="margin: 1.5rem 0 0.5rem">Highlights</h3>
        <ul class="list" style="display: grid; gap: 0.5rem; color: #475569;">
            <?php $__currentLoopData = $course['highlights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>• <?php echo e($highlight); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </main>
    
    <aside class="panel" style="background: #fff; border: 1px solid #e2e8f0; border-radius: 18px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); padding: 1.5rem;">
        <h3>Course Details</h3>
        <div class="list" style="display: grid; gap: 0.5rem; color: #475569; margin: 1rem 0;">
            <div>• Duration: <?php echo e($course['duration']); ?></div>
            <div>• Price: <?php echo e($course['price']); ?></div>
            <div>• Format: Online/Onsite</div>
            <div>• Certificate included</div>
        </div>
        <?php if(isset($course['associated_program'])): ?>
            <a href="<?php echo e(route('enroll', ['program' => $course['associated_program']['slug']])); ?>" class="btn" style="display: inline-block; margin-top: 1rem; padding: 0.8rem 1.2rem; border-radius: 12px; font-weight: 700; background: #2dd4bf; color: #0b1220; text-decoration: none;">Enroll in <?php echo e($course['associated_program']['title']); ?></a>
        <?php else: ?>
            <a href="<?php echo e(route('enroll')); ?>" class="btn" style="display: inline-block; margin-top: 1rem; padding: 0.8rem 1.2rem; border-radius: 12px; font-weight: 700; background: #2dd4bf; color: #0b1220; text-decoration: none;">View Programs</a>
        <?php endif; ?>
    </aside>
</div>

<style>
@media (max-width: 1000px) {
    .container {
        grid-template-columns: 1fr !important;
    }
}

body.dark .panel {
    background: #0f172a !important;
    border-color: #1f2937 !important;
    box-shadow: 0 6px 18px rgba(0,0,0,0.35) !important;
}

body.dark .list {
    color: #94a3b8 !important;
}

body.dark .subtitle {
    color: #94a3b8 !important;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/courses/show.blade.php ENDPATH**/ ?>