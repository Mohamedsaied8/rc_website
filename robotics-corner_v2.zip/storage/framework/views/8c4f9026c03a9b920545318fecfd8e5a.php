<?php
    $contactEmail = \App\Models\SiteSetting::get('contact_email', 'info@roboticscorner.com');
    $contactPhone = \App\Models\SiteSetting::get('contact_phone', '+20 111 115 9633');
    $contactAddress = \App\Models\SiteSetting::get('contact_address', 'Cairo, Egypt');
    $whatsappNumber = \App\Models\SiteSetting::get('whatsapp_number', '+0201111159633');
?>



<?php $__env->startSection('title', 'Contact Us - Robotics Corner'); ?>
<?php $__env->startSection('description', 'Get in touch with Robotics Corner for course inquiries, enrollment, or support.'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero compact">
    <div class="container">
        <h1 class="section-title">Contact Us</h1>
        <p class="section-subtitle">We're here to help you succeed in your technical journey</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: start;">
            <div class="contact-form" style="background: #fff; padding: 2rem; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                <h2 style="margin-bottom: 1.5rem; color: #1e293b;">Send us a Message</h2>
                
                <?php if(session('success')): ?>
                <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                
                <form method="POST" action="<?php echo e(route('contact.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div style="margin-bottom: 1.5rem;">
                        <label for="name" style="display: block; margin-bottom: 0.5rem; color: #374151; font-weight: 600;">Full Name</label>
                        <input type="text" id="name" name="name" required style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem;" value="<?php echo e(old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: #dc2626; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <label for="email" style="display: block; margin-bottom: 0.5rem; color: #374151; font-weight: 600;">Email</label>
                        <input type="email" id="email" name="email" required style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem;" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: #dc2626; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <label for="subject" style="display: block; margin-bottom: 0.5rem; color: #374151; font-weight: 600;">Subject</label>
                        <input type="text" id="subject" name="subject" required style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem;" value="<?php echo e(old('subject')); ?>">
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: #dc2626; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <label for="message" style="display: block; margin-bottom: 0.5rem; color: #374151; font-weight: 600;">Message</label>
                        <textarea id="message" name="message" rows="5" required style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem; resize: vertical;"><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: #dc2626; font-size: 0.875rem; margin-top: 0.25rem;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <button type="submit" class="btn-primary" style="width: 100%; padding: 0.75rem; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;">Send Message</button>
                </form>
            </div>
            
            <div class="contact-info">
                <h2 style="margin-bottom: 1.5rem; color: #1e293b;">Get in Touch</h2>
                
                <div class="contact-cards" style="display: grid; gap: 1.5rem;">
                    <div class="contact-card" style="background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center;">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">📱</div>
                        <h3 style="color: #1e293b; margin-bottom: 0.5rem;">WhatsApp</h3>
                        <p style="color: #64748b; margin-bottom: 1rem;">Quick support and inquiries</p>
                        <a href="https://wa.me/<?php echo e(str_replace(['+', ' '], '', $whatsappNumber)); ?>" target="_blank" rel="noopener" style="color: #2dd4bf; text-decoration: none; font-weight: 600;"><?php echo e($contactPhone); ?></a>
                    </div>
                    
                    <div class="contact-card" style="background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center;">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">📧</div>
                        <h3 style="color: #1e293b; margin-bottom: 0.5rem;">Email</h3>
                        <p style="color: #64748b; margin-bottom: 1rem;">Detailed inquiries and support</p>
                        <a href="mailto:<?php echo e($contactEmail); ?>" style="color: #2dd4bf; text-decoration: none; font-weight: 600;"><?php echo e($contactEmail); ?></a>
                    </div>
                    
                    <div class="contact-card" style="background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center;">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">📍</div>
                        <h3 style="color: #1e293b; margin-bottom: 0.5rem;">Location</h3>
                        <p style="color: #64748b; margin-bottom: 1rem;">Visit our training center</p>
                        <p style="color: #64748b; font-weight: 600;"><?php echo e($contactAddress); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
@media (max-width: 768px) {
    .container > div {
        grid-template-columns: 1fr !important;
        gap: 2rem !important;
    }
}

body.dark .contact-form {
    background: #0f172a !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2) !important;
}

body.dark .contact-form h2 {
    color: #e2e8f0 !important;
}

body.dark .contact-form label {
    color: #cbd5e1 !important;
}

body.dark .contact-form input,
body.dark .contact-form textarea {
    background: #1e293b !important;
    border-color: #334155 !important;
    color: #e2e8f0 !important;
}

body.dark .contact-card {
    background: #0f172a !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2) !important;
}

body.dark .contact-card h3 {
    color: #e2e8f0 !important;
}

body.dark .contact-card p {
    color: #94a3b8 !important;
}

body.dark .contact-info h2 {
    color: #e2e8f0 !important;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/contact.blade.php ENDPATH**/ ?>