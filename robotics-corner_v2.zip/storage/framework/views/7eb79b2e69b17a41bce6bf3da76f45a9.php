

<?php $__env->startSection('title', $page->title . ' - Robotics Corner'); ?>
<?php $__env->startSection('description', $page->meta_description ?: Str::limit($page->title . ' - Robotics Corner', 150)); ?>

<?php $__env->startSection('content'); ?>
<?php if($page->sections->count() > 0): ?>
    <?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('sections.' . $section->type, ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 2rem 1rem;">
        <div class="page-header" style="text-align: center; margin-bottom: 3rem;">
            <h1 style="font-size: 2.5rem; font-weight: 700; color: #1e293b; margin-bottom: 1rem;"><?php echo e($page->title); ?></h1>
            <?php if($page->is_special): ?>
                <div style="display: inline-block; background: #2dd4bf; color: white; padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.9rem; font-weight: 500;">
                    Home Page
                </div>
            <?php endif; ?>
        </div>

        <div class="page-content" style="max-width: 800px; margin: 0 auto; line-height: 1.7; color: #374151;">
            <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <p>This page is being built. Please check back later.</p>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/pages/show.blade.php ENDPATH**/ ?>