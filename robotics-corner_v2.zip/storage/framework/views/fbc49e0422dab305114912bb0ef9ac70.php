

<?php $__env->startSection('title', 'Programs Management'); ?>
<?php $__env->startSection('page-title', 'Programs Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h3>All Programs</h3>
        <a href="<?php echo e(route('admin.programs.create')); ?>" class="btn btn-primary">Add New Program</a>
    </div>

    <?php if($programs->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Slug</th>
                    <th>Duration</th>
                    <th>Price</th>
                    <th>Courses</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <strong><?php echo e($program->title); ?></strong>
                        <br>
                        <small style="color: #64748b;"><?php echo e(Str::limit($program->short_description, 50)); ?></small>
                    </td>
                    <td>
                        <code style="background: #f1f5f9; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;"><?php echo e($program->slug); ?></code>
                    </td>
                    <td><?php echo e($program->duration); ?></td>
                    <td><?php echo e($program->currency); ?> <?php echo e(number_format($program->price, 2)); ?></td>
                    <td>
                        <?php if($program->courses->count() > 0): ?>
                            <span style="background: #e0f2fe; color: #0369a1; padding: 0.25rem 0.5rem; border-radius: 12px; font-size: 0.8rem;"><?php echo e($program->courses->count()); ?> courses</span>
                        <?php else: ?>
                            <span style="color: #64748b; font-style: italic;">No courses</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-badge <?php echo e($program->is_active ? 'status-approved' : 'status-pending'); ?>">
                            <?php echo e($program->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td>
                        <div style="display: flex; gap: 0.5rem;">
                            <a href="<?php echo e(route('admin.programs.show', $program)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">View</a>
                            <a href="<?php echo e(route('admin.programs.edit', $program)); ?>" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Edit</a>
                            <form method="POST" action="<?php echo e(route('admin.programs.destroy', $program)); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this program?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 1.5rem;">
            <?php echo e($programs->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 3rem; color: #64748b;">
            <h4>No programs found</h4>
            <p>Get started by creating your first program.</p>
            <a href="<?php echo e(route('admin.programs.create')); ?>" class="btn btn-primary" style="margin-top: 1rem;">Create First Program</a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/programs/index.blade.php ENDPATH**/ ?>