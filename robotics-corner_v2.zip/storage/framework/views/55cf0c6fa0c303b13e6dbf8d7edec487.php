

<?php $__env->startSection('title', 'View Course'); ?>
<?php $__env->startSection('page-title', 'Course Details: ' . $course->title); ?>

<?php $__env->startSection('content'); ?>
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
    <div class="card">
        <h3 style="margin-bottom: 1rem;">Course Information</h3>
        
        <div style="display: grid; gap: 1rem;">
            <div>
                <strong>Title:</strong>
                <p><?php echo e($course->title); ?></p>
            </div>
            
            <div>
                <strong>Slug:</strong>
                <p><code style="background: #f1f5f9; padding: 0.25rem 0.5rem; border-radius: 4px;"><?php echo e($course->slug); ?></code></p>
            </div>
            
            <div>
                <strong>Short Description:</strong>
                <p><?php echo e($course->short_description); ?></p>
            </div>
            
            <div>
                <strong>Full Description:</strong>
                <p style="white-space: pre-wrap;"><?php echo e($course->description); ?></p>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                <div>
                    <strong>Duration:</strong>
                    <p><?php echo e($course->duration); ?></p>
                </div>
                <div>
                    <strong>Price:</strong>
                    <p>$<?php echo e(number_format($course->price, 2)); ?></p>
                </div>
                <div>
                    <strong>Sort Order:</strong>
                    <p><?php echo e($course->sort_order); ?></p>
                </div>
            </div>
            
            <?php if($course->image): ?>
            <div>
                <strong>Image URL:</strong>
                <p><a href="<?php echo e($course->image); ?>" target="_blank" style="color: #2dd4bf;"><?php echo e($course->image); ?></a></p>
            </div>
            <?php endif; ?>
            
            <?php if($course->video_url): ?>
            <div>
                <strong>Video URL:</strong>
                <p><a href="<?php echo e($course->video_url); ?>" target="_blank" style="color: #2dd4bf;"><?php echo e($course->video_url); ?></a></p>
            </div>
            <?php endif; ?>
            
            <div>
                <strong>Status:</strong>
                <p>
                    <span class="status-badge <?php echo e($course->is_active ? 'status-approved' : 'status-pending'); ?>">
                        <?php echo e($course->is_active ? 'Active' : 'Inactive'); ?>

                    </span>
                </p>
            </div>
        </div>
    </div>
    
    <div>
        <div class="card">
            <h3 style="margin-bottom: 1rem;">Topics</h3>
            <?php if($course->topics && count($course->topics) > 0): ?>
                <ul style="list-style: none; padding: 0;">
                    <?php $__currentLoopData = $course->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="padding: 0.5rem 0; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; gap: 0.5rem;">
                        <span style="color: #2dd4bf;">✓</span>
                        <?php echo e($topic); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p style="color: #64748b; font-style: italic;">No topics defined</p>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h3 style="margin-bottom: 1rem;">Associated Programs</h3>
            <?php if($course->programs->count() > 0): ?>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <?php $__currentLoopData = $course->programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="background: #f8fafc; padding: 0.75rem; border-radius: 8px; border-left: 4px solid #2dd4bf;">
                        <strong><?php echo e($program->title); ?></strong>
                        <br>
                        <small style="color: #64748b;"><?php echo e($program->short_description); ?></small>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p style="color: #64748b; font-style: italic;">No programs associated</p>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h3 style="margin-bottom: 1rem;">Actions</h3>
            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="btn btn-primary">Edit Course</a>
                <a href="<?php echo e(route('courses.show', $course->slug)); ?>" target="_blank" class="btn btn-secondary">View on Site</a>
                <form method="POST" action="<?php echo e(route('admin.courses.destroy', $course)); ?>" onsubmit="return confirm('Are you sure you want to delete this course?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" style="width: 100%;">Delete Course</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div style="margin-top: 2rem;">
    <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-secondary">← Back to Courses</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/courses/show.blade.php ENDPATH**/ ?>