<!-- Two Column Section -->
<section class="two-column-section">
    <div class="container">
        <div class="two-column-content">
            <div class="column left-column">
                <?php if(isset($section->content['left_image']) && $section->content['left_image']): ?>
                    <img src="<?php echo e($section->content['left_image']); ?>" alt="Left Column Image" class="column-image">
                <?php endif; ?>
                <?php if(isset($section->content['left_content'])): ?>
                    <div class="column-text">
                        <?php echo nl2br(e($section->content['left_content'])); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="column right-column">
                <?php if(isset($section->content['right_image']) && $section->content['right_image']): ?>
                    <img src="<?php echo e($section->content['right_image']); ?>" alt="Right Column Image" class="column-image">
                <?php endif; ?>
                <?php if(isset($section->content['right_content'])): ?>
                    <div class="column-text">
                        <?php echo nl2br(e($section->content['right_content'])); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/sections/two_column.blade.php ENDPATH**/ ?>