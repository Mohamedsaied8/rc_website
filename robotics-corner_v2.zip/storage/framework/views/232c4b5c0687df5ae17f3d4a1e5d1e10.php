

<?php $__env->startSection('title', 'View Page'); ?>
<?php $__env->startSection('page-title', 'View Page: ' . $page->title); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h3 style="margin: 0; color: #1e293b;">Page Details</h3>
        <div style="display: flex; gap: 0.5rem;">
            <a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="btn btn-primary">Edit Page</a>
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-secondary">Back to List</a>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
        <div>
            <h4 style="color: #374151; margin-bottom: 0.5rem;">Basic Information</h4>
            <div style="background: #f8fafc; padding: 1rem; border-radius: 8px;">
                <div style="margin-bottom: 1rem;">
                    <strong>Title:</strong><br>
                    <span style="color: #1e293b;"><?php echo e($page->title); ?></span>
                </div>
                <div style="margin-bottom: 1rem;">
                    <strong>Slug:</strong><br>
                    <code style="background: #e2e8f0; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.9rem;"><?php echo e($page->slug); ?></code>
                </div>
                <div style="margin-bottom: 1rem;">
                    <strong>Page Type:</strong><br>
                    <span class="status-badge <?php echo e($page->is_special ? 'status-completed' : 'status-pending'); ?>">
                        <?php echo e($page->page_type); ?>

                    </span>
                </div>
                <div>
                    <strong>Status:</strong><br>
                    <span class="status-badge <?php echo e($page->is_active ? 'status-approved' : 'status-rejected'); ?>">
                        <?php echo e($page->status); ?>

                    </span>
                </div>
            </div>
        </div>

        <div>
            <h4 style="color: #374151; margin-bottom: 0.5rem;">Timestamps</h4>
            <div style="background: #f8fafc; padding: 1rem; border-radius: 8px;">
                <div style="margin-bottom: 1rem;">
                    <strong>Created:</strong><br>
                    <span style="color: #64748b;"><?php echo e($page->created_at->format('M d, Y \a\t g:i A')); ?></span>
                </div>
                <div>
                    <strong>Last Updated:</strong><br>
                    <span style="color: #64748b;"><?php echo e($page->updated_at->format('M d, Y \a\t g:i A')); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div>
        <h4 style="color: #374151; margin-bottom: 0.5rem;">Content Preview</h4>
        <div style="background: #f8fafc; padding: 1.5rem; border-radius: 8px; border: 1px solid #e2e8f0;">
            <div style="white-space: pre-wrap; line-height: 1.6; color: #374151;">
                <?php echo $page->content; ?>

            </div>
        </div>
    </div>

    <?php if($page->is_special): ?>
        <div style="margin-top: 1.5rem; padding: 1rem; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px;">
            <strong style="color: #92400e;">⚠️ Special Page Notice:</strong>
            <p style="color: #92400e; margin: 0.5rem 0 0 0;">This is a special page (Home Page) and cannot be deleted. Only one special page is allowed in the system.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/pages/show.blade.php ENDPATH**/ ?>