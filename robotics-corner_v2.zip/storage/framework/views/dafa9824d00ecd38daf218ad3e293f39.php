<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <div class="hero-text">
                <h1><?php echo $section->content['title'] ?? 'Welcome to Robotics Corner'; ?></h1>
                <p class="hero-description"><?php echo e($section->content['subtitle'] ?? 'Your premier destination for professional robotics and software engineering education.'); ?></p>
                <?php if(isset($section->content['button_text']) && isset($section->content['button_link'])): ?>
                    <div class="hero-buttons">
                        <a href="<?php echo e($section->content['button_link']); ?>" class="btn-primary"><?php echo e($section->content['button_text']); ?> →</a>
                    </div>
                <?php endif; ?>
            </div>
            <?php if(isset($section->content['video_url']) && $section->content['video_url']): ?>
                <div class="hero-video">
                    <div class="video-content" style="width:100%;height:100%;padding:0">
                        <iframe width="100%" height="315" style="min-height:315px;border:0;border-radius:12px" src="<?php echo e($section->content['video_url']); ?>" title="Robotics Corner" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/sections/hero.blade.php ENDPATH**/ ?>