

<?php $__env->startSection('title', 'Edit Page'); ?>
<?php $__env->startSection('page-title', 'Edit Page: ' . $page->title); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <form method="POST" action="<?php echo e(route('admin.pages.update', $page)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="title" class="form-label">Title *</label>
            <input type="text" id="title" name="title" class="form-input" value="<?php echo e(old('title', $page->title)); ?>" required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="slug" class="form-label">Slug</label>
            <input type="text" id="slug" name="slug" class="form-input" value="<?php echo e(old('slug', $page->slug)); ?>">
            <small style="color: #64748b; font-size: 0.8rem;">Leave empty to auto-generate from title</small>
            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($page->is_special): ?>
            <!-- Special Home Page Editor -->
            <div class="card" style="margin-bottom: 2rem;">
                <h3 style="color: #1e293b; margin-bottom: 1.5rem;">🏠 Home Page Structure</h3>
                
                <div class="form-group">
                    <label for="hero_title" class="form-label">Hero Title *</label>
                    <input type="text" id="hero_title" name="hero_title" class="form-input" value="<?php echo e(old('hero_title', $page->hero_title)); ?>" required>
                    <?php $__errorArgs = ['hero_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="hero_subtitle" class="form-label">Hero Subtitle *</label>
                    <textarea id="hero_subtitle" name="hero_subtitle" class="form-textarea" rows="3" required><?php echo e(old('hero_subtitle', $page->hero_subtitle)); ?></textarea>
                    <?php $__errorArgs = ['hero_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="hero_video_url" class="form-label">Hero Video URL</label>
                    <input type="url" id="hero_video_url" name="hero_video_url" class="form-input" value="<?php echo e(old('hero_video_url', $page->hero_video_url)); ?>">
                    <?php $__errorArgs = ['hero_video_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label class="form-label">Hero Stats</label>
                    <div id="hero-stats-container">
                        <?php if($page->hero_stats): ?>
                            <?php $__currentLoopData = $page->hero_stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="stat-row" style="display: flex; gap: 1rem; margin-bottom: 1rem;">
                                    <input type="text" name="hero_stats[<?php echo e($index); ?>][number]" placeholder="Number" value="<?php echo e($stat['number'] ?? ''); ?>" class="form-input" style="flex: 1;">
                                    <input type="text" name="hero_stats[<?php echo e($index); ?>][label]" placeholder="Label" value="<?php echo e($stat['label'] ?? ''); ?>" class="form-input" style="flex: 2;">
                                    <button type="button" class="btn btn-danger" onclick="removeStat(this)" style="padding: 0.5rem;">Remove</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="stat-row" style="display: flex; gap: 1rem; margin-bottom: 1rem;">
                                <input type="text" name="hero_stats[0][number]" placeholder="Number" class="form-input" style="flex: 1;">
                                <input type="text" name="hero_stats[0][label]" placeholder="Label" class="form-input" style="flex: 2;">
                                <button type="button" class="btn btn-danger" onclick="removeStat(this)" style="padding: 0.5rem;">Remove</button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-secondary" onclick="addStat()" style="margin-top: 0.5rem;">Add Stat</button>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label for="cta_primary_text" class="form-label">Primary CTA Text *</label>
                        <input type="text" id="cta_primary_text" name="cta_primary_text" class="form-input" value="<?php echo e(old('cta_primary_text', $page->cta_primary_text)); ?>" required>
                        <?php $__errorArgs = ['cta_primary_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="cta_primary_link" class="form-label">Primary CTA Link *</label>
                        <input type="text" id="cta_primary_link" name="cta_primary_link" class="form-input" value="<?php echo e(old('cta_primary_link', $page->cta_primary_link)); ?>" required>
                        <?php $__errorArgs = ['cta_primary_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label for="cta_secondary_text" class="form-label">Secondary CTA Text</label>
                        <input type="text" id="cta_secondary_text" name="cta_secondary_text" class="form-input" value="<?php echo e(old('cta_secondary_text', $page->cta_secondary_text)); ?>">
                        <?php $__errorArgs = ['cta_secondary_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="cta_secondary_link" class="form-label">Secondary CTA Link</label>
                        <input type="text" id="cta_secondary_link" name="cta_secondary_link" class="form-input" value="<?php echo e(old('cta_secondary_link', $page->cta_secondary_link)); ?>">
                        <?php $__errorArgs = ['cta_secondary_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="meta_description" class="form-label">Meta Description</label>
                    <textarea id="meta_description" name="meta_description" class="form-textarea" rows="2" maxlength="160"><?php echo e(old('meta_description', $page->meta_description)); ?></textarea>
                    <small style="color: #64748b; font-size: 0.8rem;">Max 160 characters for SEO</small>
                    <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        <?php else: ?>
            <!-- Dynamic Page Editor -->
            <div class="form-group">
                <label for="content" class="form-label">Content *</label>
                <textarea id="content" name="content" class="form-textarea" rows="10" required><?php echo e(old('content', $page->content)); ?></textarea>
                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <div class="form-group">
                <label class="form-label">Page Type</label>
                <div style="display: flex; gap: 1rem; margin-top: 0.5rem;">
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="radio" name="is_special" value="0" <?php echo e(old('is_special', $page->is_special ? '1' : '0') == '0' ? 'checked' : ''); ?>>
                        <span>Dynamic</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="radio" name="is_special" value="1" <?php echo e(old('is_special', $page->is_special ? '1' : '0') == '1' ? 'checked' : ''); ?>>
                        <span>Special (Home Page)</span>
                    </label>
                </div>
                <?php $__errorArgs = ['is_special'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="form-label">Status</label>
                <div style="display: flex; gap: 1rem; margin-top: 0.5rem;">
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="radio" name="is_active" value="1" <?php echo e(old('is_active', $page->is_active ? '1' : '0') == '1' ? 'checked' : ''); ?>>
                        <span>Active</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="radio" name="is_active" value="0" <?php echo e(old('is_active', $page->is_active ? '1' : '0') == '0' ? 'checked' : ''); ?>>
                        <span>Inactive</span>
                    </label>
                </div>
                <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #ef4444; font-size: 0.9rem; margin-top: 0.25rem;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
            <button type="submit" class="btn btn-primary">Update Page</button>
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-secondary">Cancel</a>
            <a href="<?php echo e(route('admin.pages.show', $page)); ?>" class="btn btn-secondary">View Page</a>
        </div>
    </form>
</div>

<script>
// Auto-generate slug from title
document.getElementById('title').addEventListener('input', function() {
    const title = this.value;
    const slug = title.toLowerCase()
        .replace(/[^a-z0-9 -]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim('-');
    
    const slugInput = document.getElementById('slug');
    if (!slugInput.value) {
        slugInput.value = slug;
    }
});

// Stats management for Home page
let statIndex = <?php echo e($page->hero_stats ? count($page->hero_stats) : 1); ?>;

function addStat() {
    const container = document.getElementById('hero-stats-container');
    const statRow = document.createElement('div');
    statRow.className = 'stat-row';
    statRow.style.cssText = 'display: flex; gap: 1rem; margin-bottom: 1rem;';
    
    statRow.innerHTML = `
        <input type="text" name="hero_stats[${statIndex}][number]" placeholder="Number" class="form-input" style="flex: 1;">
        <input type="text" name="hero_stats[${statIndex}][label]" placeholder="Label" class="form-input" style="flex: 2;">
        <button type="button" class="btn btn-danger" onclick="removeStat(this)" style="padding: 0.5rem;">Remove</button>
    `;
    
    container.appendChild(statRow);
    statIndex++;
}

function removeStat(button) {
    button.parentElement.remove();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/pages/edit.blade.php ENDPATH**/ ?>