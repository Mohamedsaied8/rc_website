<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <?php if(isset($section->content['title']) || isset($section->content['subtitle'])): ?>
            <div class="section-header">
                <?php if(isset($section->content['title'])): ?>
                    <h2 class="section-title"><?php echo e($section->content['title']); ?></h2>
                <?php endif; ?>
                <?php if(isset($section->content['subtitle'])): ?>
                    <p class="section-subtitle"><?php echo e($section->content['subtitle']); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php if(isset($section->content['features']) && is_array($section->content['features'])): ?>
            <div class="features-grid">
                <?php $__currentLoopData = $section->content['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="feature-card">
                        <?php if(isset($feature['icon']) && $feature['icon']): ?>
                            <div class="feature-icon"><?php echo e($feature['icon']); ?></div>
                        <?php endif; ?>
                        <h3 class="feature-title"><?php echo e($feature['title'] ?? 'Feature Title'); ?></h3>
                        <p class="feature-description"><?php echo e($feature['description'] ?? 'Feature description goes here.'); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/sections/features.blade.php ENDPATH**/ ?>