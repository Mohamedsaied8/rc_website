

<?php $__env->startSection('title', 'Edit Setting'); ?>
<?php $__env->startSection('page-title', 'Edit Setting: ' . ucwords(str_replace('_', ' ', $setting->key))); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <form method="POST" action="<?php echo e(route('admin.settings.update', $setting)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="key" class="form-label">Setting Key</label>
            <input type="text" id="key" name="key" class="form-input" value="<?php echo e($setting->key); ?>" readonly style="background: #f9fafb;">
            <small style="color: #6b7280; font-size: 0.875rem;">Setting key cannot be changed</small>
        </div>

        <div class="form-group">
            <label for="type" class="form-label">Type</label>
            <input type="text" id="type" name="type" class="form-input" value="<?php echo e($setting->type); ?>" readonly style="background: #f9fafb;">
            <small style="color: #6b7280; font-size: 0.875rem;">Setting type cannot be changed</small>
        </div>

        <div class="form-group">
            <label for="description" class="form-label">Description</label>
            <input type="text" id="description" name="description" class="form-input" value="<?php echo e($setting->description); ?>" readonly style="background: #f9fafb;">
            <small style="color: #6b7280; font-size: 0.875rem;">Description cannot be changed</small>
        </div>

        <div class="form-group">
            <label for="value" class="form-label">Value *</label>
            <?php if($setting->type === 'textarea'): ?>
                <textarea id="value" name="value" class="form-textarea" rows="4" required><?php echo e(old('value', $setting->value)); ?></textarea>
            <?php elseif($setting->type === 'url'): ?>
                <input type="url" id="value" name="value" class="form-input" value="<?php echo e(old('value', $setting->value)); ?>" required>
            <?php elseif($setting->type === 'email'): ?>
                <input type="email" id="value" name="value" class="form-input" value="<?php echo e(old('value', $setting->value)); ?>" required>
            <?php elseif($setting->type === 'phone'): ?>
                <input type="tel" id="value" name="value" class="form-input" value="<?php echo e(old('value', $setting->value)); ?>" required>
            <?php else: ?>
                <input type="text" id="value" name="value" class="form-input" value="<?php echo e(old('value', $setting->value)); ?>" required>
            <?php endif; ?>
            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: #ef4444; font-size: 0.875rem;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
            <button type="submit" class="btn-primary">Update Setting</button>
            <a href="<?php echo e(route('admin.settings.index')); ?>" class="btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>