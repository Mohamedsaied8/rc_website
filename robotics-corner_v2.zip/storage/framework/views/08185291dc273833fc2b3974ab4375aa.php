

<?php $__env->startSection('title', 'Enrollments Management'); ?>
<?php $__env->startSection('page-title', 'Enrollments Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h3>All Enrollments</h3>
        <div style="display: flex; gap: 1rem; align-items: center;">
            <form method="GET" style="display: flex; gap: 0.5rem; align-items: center;">
                <input type="text" name="search" placeholder="Search by name or email..." class="form-input" value="<?php echo e(request('search')); ?>" style="width: 250px;">
                <select name="status" class="form-input" style="width: 150px;">
                    <option value="">All Status</option>
                    <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="approved" <?php echo e(request('status') === 'approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                    <option value="completed" <?php echo e(request('status') === 'completed' ? 'selected' : ''); ?>>Completed</option>
                </select>
                <button type="submit" class="btn btn-secondary">Filter</button>
                <?php if(request('search') || request('status')): ?>
                    <a href="<?php echo e(route('admin.enrollments.index')); ?>" class="btn btn-secondary">Clear</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <?php if($enrollments->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Program</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <strong><?php echo e($enrollment->first_name); ?> <?php echo e($enrollment->last_name); ?></strong>
                        <br>
                        <small style="color: #64748b;"><?php echo e($enrollment->country); ?>, <?php echo e($enrollment->city); ?></small>
                    </td>
                    <td>
                        <a href="mailto:<?php echo e($enrollment->email); ?>" style="color: #2dd4bf;"><?php echo e($enrollment->email); ?></a>
                    </td>
                    <td>
                        <a href="tel:<?php echo e($enrollment->phone); ?>" style="color: #2dd4bf;"><?php echo e($enrollment->phone); ?></a>
                    </td>
                    <td><?php echo e($enrollment->selected_program); ?></td>
                    <td>
                        <?php if($enrollment->payment_method): ?>
                            <span class="badge badge-<?php echo e($enrollment->payment_method === 'instapay' ? 'primary' : 'secondary'); ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $enrollment->payment_method))); ?>

                            </span>
                        <?php else: ?>
                            <span style="color: #64748b;">Not specified</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-badge status-<?php echo e($enrollment->status); ?>">
                            <?php echo e(ucfirst($enrollment->status)); ?>

                        </span>
                    </td>
                    <td><?php echo e($enrollment->created_at->format('M d, Y')); ?></td>
                    <td>
                        <div style="display: flex; gap: 0.5rem;">
                            <a href="<?php echo e(route('admin.enrollments.show', $enrollment)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">View</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 1.5rem;">
            <?php echo e($enrollments->appends(request()->query())->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 3rem; color: #64748b;">
            <h4>No enrollments found</h4>
            <p>No enrollments match your current filters.</p>
            <?php if(request('search') || request('status')): ?>
                <a href="<?php echo e(route('admin.enrollments.index')); ?>" class="btn btn-secondary" style="margin-top: 1rem;">Clear Filters</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-top: 2rem;">
    <div class="card">
        <h3 style="margin-bottom: 1rem; color: #1e293b;">Quick Stats</h3>
        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
            <div style="display: flex; justify-content: space-between;">
                <span>Total:</span>
                <strong><?php echo e($enrollments->total()); ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span>Pending:</span>
                <span style="color: #f59e0b;"><?php echo e($enrollments->where('status', 'pending')->count()); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span>Approved:</span>
                <span style="color: #10b981;"><?php echo e($enrollments->where('status', 'approved')->count()); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span>Rejected:</span>
                <span style="color: #ef4444;"><?php echo e($enrollments->where('status', 'rejected')->count()); ?></span>
            </div>
        </div>
    </div>

    <div class="card">
        <h3 style="margin-bottom: 1rem; color: #1e293b;">Recent Activity</h3>
        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
            <?php $__currentLoopData = $enrollments->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="padding: 0.5rem; background: #f8fafc; border-radius: 6px; font-size: 0.9rem;">
                <strong><?php echo e($enrollment->first_name); ?> <?php echo e($enrollment->last_name); ?></strong>
                <br>
                <small style="color: #64748b;"><?php echo e($enrollment->created_at->diffForHumans()); ?></small>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/enrollments/index.blade.php ENDPATH**/ ?>