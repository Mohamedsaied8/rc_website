<?php
    $programs = \App\Models\Program::where('is_active', true)->orderBy('sort_order')->limit(3)->get();
    $courses = \App\Models\Course::where('is_active', true)->orderBy('sort_order')->limit(4)->get();
    $contactEmail = \App\Models\SiteSetting::get('contact_email', 'info@roboticscorner.com');
    $contactPhone = \App\Models\SiteSetting::get('contact_phone', '+20 111 115 9633');
    $contactAddress = \App\Models\SiteSetting::get('contact_address', 'Cairo, Egypt');
    $facebookUrl = \App\Models\SiteSetting::get('facebook_url', 'https://facebook.com/roboticscorner');
    $twitterUrl = \App\Models\SiteSetting::get('twitter_url', 'https://twitter.com/roboticscorner');
    $linkedinUrl = \App\Models\SiteSetting::get('linkedin_url', 'https://linkedin.com/company/roboticscorner');
    $youtubeUrl = \App\Models\SiteSetting::get('youtube_url', 'https://youtube.com/@roboticscorner9870');
    $siteTitle = \App\Models\SiteSetting::get('site_title', 'Robotics Corner');
    $siteTagline = \App\Models\SiteSetting::get('site_tagline', 'Empowering engineers with cutting-edge robotics and software engineering skills.');
?>

<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3><?php echo e($siteTitle); ?></h3>
                <p><?php echo e($siteTagline); ?></p>
                <div class="social-links">
                    <a href="<?php echo e($facebookUrl); ?>" aria-label="Facebook" target="_blank">📘</a>
                    <a href="<?php echo e($twitterUrl); ?>" aria-label="Twitter" target="_blank">🐦</a>
                    <a href="<?php echo e($linkedinUrl); ?>" aria-label="LinkedIn" target="_blank">💼</a>
                    <a href="<?php echo e($youtubeUrl); ?>" aria-label="YouTube" target="_blank">📺</a>
                </div>
            </div>
            
            <div class="footer-section">
                <h4>Programs</h4>
                <ul>
                    <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('programs.show', $program->slug)); ?>"><?php echo e($program->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Courses</h4>
                <ul>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('courses.show', $course->slug)); ?>"><?php echo e($course->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Contact</h4>
                <div class="contact-info">
                    <p>📧 <?php echo e($contactEmail); ?></p>
                    <p>📱 <?php echo e($contactPhone); ?></p>
                    <p>📍 <?php echo e($contactAddress); ?></p>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo e(date('Y')); ?> Robotics Corner. All rights reserved.</p>
            <div class="footer-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/components/footer.blade.php ENDPATH**/ ?>