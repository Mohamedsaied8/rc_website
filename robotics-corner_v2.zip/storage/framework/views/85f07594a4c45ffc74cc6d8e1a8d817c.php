

<?php $__env->startSection('title', 'Page Builder - ' . $page->title); ?>
<?php $__env->startSection('page-title', 'Page Builder: ' . $page->title); ?>

<?php $__env->startSection('content'); ?>
<div class="page-builder">
    <div class="builder-header">
        <div class="page-info">
            <h3><?php echo e($page->title); ?></h3>
            <span class="page-type-badge <?php echo e($page->is_special ? 'special' : 'dynamic'); ?>">
                <?php echo e($page->page_type); ?>

            </span>
        </div>
        <div class="builder-actions">
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-secondary">← Back to Pages</a>
            <a href="<?php echo e(route('pages.show', $page->slug)); ?>" target="_blank" class="btn btn-primary">View Page</a>
        </div>
    </div>

    <!-- Add Section Modal -->
    <div class="add-section-modal" id="addSectionModal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add New Section</h3>
                <button onclick="closeAddSectionModal()" class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
                <div class="section-types-grid">
                    <?php $__currentLoopData = $sectionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="section-type-card" onclick="selectSectionType('<?php echo e($type); ?>')">
                            <div class="section-type-icon"><?php echo e($config['title'][0]); ?></div>
                            <h4><?php echo e($config['title']); ?></h4>
                            <p><?php echo e($config['description']); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Sections List -->
    <div class="sections-container">
        <div class="sections-header">
            <h4>Page Sections</h4>
            <button onclick="openAddSectionModal()" class="btn btn-primary">+ Add Section</button>
        </div>

        <div class="sections-list" id="sectionsList">
            <?php if($sections->count() > 0): ?>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="section-item" data-section-id="<?php echo e($section->id); ?>">
                        <div class="section-handle">⋮⋮</div>
                        <div class="section-info">
                            <div class="section-type"><?php echo e($sectionTypes[$section->type]['title'] ?? $section->type); ?></div>
                            <div class="section-preview">
                                <?php if($section->type === 'hero'): ?>
                                    <?php echo e($section->content['title'] ?? 'Hero Section'); ?>

                                <?php elseif($section->type === 'stats'): ?>
                                    <?php echo e(count($section->content['stats'] ?? [])); ?> statistics
                                <?php elseif($section->type === 'features'): ?>
                                    <?php echo e(count($section->content['features'] ?? [])); ?> features
                                <?php else: ?>
                                    <?php echo e(ucfirst($section->type)); ?> Section
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="section-actions">
                            <button onclick="editSection(<?php echo e($section->id); ?>)" class="btn btn-sm btn-secondary">Edit</button>
                            <button onclick="toggleSection(<?php echo e($section->id); ?>)" class="btn btn-sm <?php echo e($section->is_active ? 'btn-warning' : 'btn-success'); ?>">
                                <?php echo e($section->is_active ? 'Hide' : 'Show'); ?>

                            </button>
                            <button onclick="deleteSection(<?php echo e($section->id); ?>)" class="btn btn-sm btn-danger">Delete</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="empty-state">
                    <p>No sections added yet. Click "Add Section" to get started.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Section Edit Modal -->
<div class="section-edit-modal" id="sectionEditModal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Edit Section</h3>
            <button onclick="closeEditModal()" class="close-btn">&times;</button>
        </div>
        <div class="modal-body">
            <form id="sectionEditForm">
                <?php echo csrf_field(); ?>
                <div id="sectionFields"></div>
                <div class="form-actions">
                    <button type="button" onclick="closeEditModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.page-builder {
    max-width: 1200px;
    margin: 0 auto;
}

.builder-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding: 1.5rem;
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.page-info h3 {
    margin: 0;
    color: #1e293b;
}

.page-type-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
    margin-left: 1rem;
}

.page-type-badge.special {
    background: #dbeafe;
    color: #1e40af;
}

.page-type-badge.dynamic {
    background: #d1fae5;
    color: #065f46;
}

.sections-container {
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    overflow: hidden;
}

.sections-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #e2e8f0;
}

.sections-list {
    min-height: 200px;
}

.section-item {
    display: flex;
    align-items: center;
    padding: 1rem 1.5rem;
    border-bottom: 1px solid #e2e8f0;
    cursor: move;
}

.section-item:hover {
    background: #f8fafc;
}

.section-handle {
    color: #64748b;
    margin-right: 1rem;
    cursor: grab;
}

.section-info {
    flex: 1;
}

.section-type {
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 0.25rem;
}

.section-preview {
    color: #64748b;
    font-size: 0.9rem;
}

.section-actions {
    display: flex;
    gap: 0.5rem;
}

.add-section-modal, .section-edit-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-content {
    background: white;
    border-radius: 12px;
    max-width: 800px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #e2e8f0;
}

.modal-body {
    padding: 1.5rem;
}

.section-types-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.section-type-card {
    padding: 1.5rem;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.section-type-card:hover {
    border-color: #2dd4bf;
    background: #f0fdfa;
}

.section-type-icon {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.empty-state {
    text-align: center;
    padding: 3rem;
    color: #64748b;
}

.form-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #e2e8f0;
}
</style>

<script>
let currentSectionId = null;
let currentSectionType = null;

function openAddSectionModal() {
    document.getElementById('addSectionModal').style.display = 'flex';
}

function closeAddSectionModal() {
    document.getElementById('addSectionModal').style.display = 'none';
}

function selectSectionType(type) {
    currentSectionType = type;
    closeAddSectionModal();
    
    // Create a new section with default content
    const sectionTypes = <?php echo json_encode($sectionTypes, 15, 512) ?>;
    const config = sectionTypes[type];
    
    // Build form for this section type
    buildSectionForm(type, config, {});
}

function buildSectionForm(type, config, content) {
    const formHtml = generateFormFields(config.fields, content);
    
    document.getElementById('sectionFields').innerHTML = formHtml;
    document.getElementById('sectionEditModal').style.display = 'flex';
}

function generateFormFields(fields, content) {
    let html = '';
    
    for (const [fieldName, fieldConfig] of Object.entries(fields)) {
        html += generateFieldHtml(fieldName, fieldConfig, content[fieldName] || '');
    }
    
    return html;
}

function generateFieldHtml(fieldName, fieldConfig, value) {
    const required = fieldConfig.required ? 'required' : '';
    const label = fieldConfig.label;
    
    switch (fieldConfig.type) {
        case 'text':
        case 'email':
        case 'url':
            return `
                <div class="form-group">
                    <label for="${fieldName}">${label} ${fieldConfig.required ? '*' : ''}</label>
                    <input type="${fieldConfig.type}" id="${fieldName}" name="${fieldName}" value="${value}" ${required} class="form-input">
                </div>
            `;
        case 'textarea':
            return `
                <div class="form-group">
                    <label for="${fieldName}">${label} ${fieldConfig.required ? '*' : ''}</label>
                    <textarea id="${fieldName}" name="${fieldName}" ${required} class="form-textarea" rows="3">${value}</textarea>
                </div>
            `;
        case 'repeatable':
            return generateRepeatableField(fieldName, fieldConfig, value);
        default:
            return '';
    }
}

function generateRepeatableField(fieldName, fieldConfig, value) {
    const items = value || [{}];
    let html = `
        <div class="form-group">
            <label>${fieldConfig.label} ${fieldConfig.required ? '*' : ''}</label>
            <div id="${fieldName}-container">
    `;
    
    items.forEach((item, index) => {
        html += `<div class="repeatable-item">`;
        for (const [subFieldName, subFieldConfig] of Object.entries(fieldConfig.fields)) {
            html += generateFieldHtml(`${fieldName}[${index}][${subFieldName}]`, subFieldConfig, item[subFieldName] || '');
        }
        html += `<button type="button" onclick="removeRepeatableItem('${fieldName}', ${index})" class="btn btn-sm btn-danger">Remove</button>`;
        html += `</div>`;
    });
    
    html += `
            </div>
            <button type="button" onclick="addRepeatableItem('${fieldName}')" class="btn btn-sm btn-secondary">Add Item</button>
        </div>
    `;
    
    return html;
}

function addRepeatableItem(fieldName) {
    const container = document.getElementById(`${fieldName}-container`);
    const index = container.children.length;
    const fieldConfig = getFieldConfig(fieldName);
    
    let html = `<div class="repeatable-item">`;
    for (const [subFieldName, subFieldConfig] of Object.entries(fieldConfig.fields)) {
        html += generateFieldHtml(`${fieldName}[${index}][${subFieldName}]`, subFieldConfig, '');
    }
    html += `<button type="button" onclick="removeRepeatableItem('${fieldName}', ${index})" class="btn btn-sm btn-danger">Remove</button>`;
    html += `</div>`;
    
    container.insertAdjacentHTML('beforeend', html);
}

function removeRepeatableItem(fieldName, index) {
    const container = document.getElementById(`${fieldName}-container`);
    const item = container.children[index];
    if (item) {
        item.remove();
    }
}

function getFieldConfig(fieldName) {
    const sectionTypes = <?php echo json_encode($sectionTypes, 15, 512) ?>;
    const type = currentSectionType;
    return sectionTypes[type].fields[fieldName];
}

function editSection(sectionId) {
    currentSectionId = sectionId;
    // Implementation for editing existing section
    closeEditModal();
}

function closeEditModal() {
    document.getElementById('sectionEditModal').style.display = 'none';
    currentSectionId = null;
    currentSectionType = null;
}

function toggleSection(sectionId) {
    // Implementation for toggling section visibility
}

function deleteSection(sectionId) {
    if (confirm('Are you sure you want to delete this section?')) {
        // Implementation for deleting section
    }
}

// Make sections sortable
document.addEventListener('DOMContentLoaded', function() {
    const sectionsList = document.getElementById('sectionsList');
    // Add sortable functionality here
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/pages/builder.blade.php ENDPATH**/ ?>