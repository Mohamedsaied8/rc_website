

<?php $__env->startSection('title', 'View Program'); ?>
<?php $__env->startSection('page-title', 'Program Details: ' . $program->title); ?>

<?php $__env->startSection('content'); ?>
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
    <div class="card">
        <h3 style="margin-bottom: 1rem;">Program Information</h3>
        
        <div style="display: grid; gap: 1rem;">
            <div>
                <strong>Title:</strong>
                <p><?php echo e($program->title); ?></p>
            </div>
            
            <div>
                <strong>Slug:</strong>
                <p><code style="background: #f1f5f9; padding: 0.25rem 0.5rem; border-radius: 4px;"><?php echo e($program->slug); ?></code></p>
            </div>
            
            <div>
                <strong>Short Description:</strong>
                <p><?php echo e($program->short_description); ?></p>
            </div>
            
            <div>
                <strong>Full Description:</strong>
                <p style="white-space: pre-wrap;"><?php echo e($program->description); ?></p>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                <div>
                    <strong>Duration:</strong>
                    <p><?php echo e($program->duration); ?></p>
                </div>
                <div>
                    <strong>Price:</strong>
                    <p>$<?php echo e(number_format($program->price, 2)); ?></p>
                </div>
                <div>
                    <strong>Sort Order:</strong>
                    <p><?php echo e($program->sort_order); ?></p>
                </div>
            </div>
            
            <?php if($program->image): ?>
            <div>
                <strong>Image URL:</strong>
                <p><a href="<?php echo e($program->image); ?>" target="_blank" style="color: #2dd4bf;"><?php echo e($program->image); ?></a></p>
            </div>
            <?php endif; ?>
            
            <?php if($program->video_url): ?>
            <div>
                <strong>Video URL:</strong>
                <p><a href="<?php echo e($program->video_url); ?>" target="_blank" style="color: #2dd4bf;"><?php echo e($program->video_url); ?></a></p>
            </div>
            <?php endif; ?>
            
            <div>
                <strong>Status:</strong>
                <p>
                    <span class="status-badge <?php echo e($program->is_active ? 'status-approved' : 'status-pending'); ?>">
                        <?php echo e($program->is_active ? 'Active' : 'Inactive'); ?>

                    </span>
                </p>
            </div>
        </div>
    </div>
    
    <div>
        <div class="card">
            <h3 style="margin-bottom: 1rem;">Topics</h3>
            <?php if($program->topics && count($program->topics) > 0): ?>
                <ul style="list-style: none; padding: 0;">
                    <?php $__currentLoopData = $program->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="padding: 0.5rem 0; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; gap: 0.5rem;">
                        <span style="color: #2dd4bf;">✓</span>
                        <?php echo e($topic); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p style="color: #64748b; font-style: italic;">No topics defined</p>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h3 style="margin-bottom: 1rem;">Associated Courses</h3>
            <?php if($program->courses->count() > 0): ?>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <?php $__currentLoopData = $program->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="background: #f8fafc; padding: 0.75rem; border-radius: 8px; border-left: 4px solid #2dd4bf;">
                        <strong><?php echo e($course->title); ?></strong>
                        <br>
                        <small style="color: #64748b;"><?php echo e($course->short_description); ?></small>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p style="color: #64748b; font-style: italic;">No courses associated</p>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h3 style="margin-bottom: 1rem;">Actions</h3>
            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                <a href="<?php echo e(route('admin.programs.edit', $program)); ?>" class="btn btn-primary">Edit Program</a>
                <a href="<?php echo e(route('programs.show', $program->slug)); ?>" target="_blank" class="btn btn-secondary">View on Site</a>
                <form method="POST" action="<?php echo e(route('admin.programs.destroy', $program)); ?>" onsubmit="return confirm('Are you sure you want to delete this program?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" style="width: 100%;">Delete Program</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div style="margin-top: 2rem;">
    <a href="<?php echo e(route('admin.programs.index')); ?>" class="btn btn-secondary">← Back to Programs</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/programs/show.blade.php ENDPATH**/ ?>