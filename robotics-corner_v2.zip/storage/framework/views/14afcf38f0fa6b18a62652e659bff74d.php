

<?php $__env->startSection('title', 'Courses Management'); ?>
<?php $__env->startSection('page-title', 'Courses Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h3>All Courses</h3>
        <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary">Add New Course</a>
    </div>

    <?php if($courses->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Slug</th>
                    <th>Duration</th>
                    <th>Price</th>
                    <th>Programs</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <strong><?php echo e($course->title); ?></strong>
                        <br>
                        <small style="color: #64748b;"><?php echo e(Str::limit($course->short_description, 50)); ?></small>
                    </td>
                    <td>
                        <code style="background: #f1f5f9; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;"><?php echo e($course->slug); ?></code>
                    </td>
                    <td><?php echo e($course->duration); ?></td>
                    <td><?php echo e($course->currency); ?> <?php echo e(number_format($course->price, 2)); ?></td>
                    <td>
                        <?php if($course->programs->count() > 0): ?>
                            <?php $__currentLoopData = $course->programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="background: #e0f2fe; color: #0369a1; padding: 0.25rem 0.5rem; border-radius: 12px; font-size: 0.8rem; margin-right: 0.25rem; display: inline-block; margin-bottom: 0.25rem;"><?php echo e($program->title); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <span style="color: #64748b; font-style: italic;">No programs</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-badge <?php echo e($course->is_active ? 'status-approved' : 'status-pending'); ?>">
                            <?php echo e($course->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td>
                        <div style="display: flex; gap: 0.5rem;">
                            <a href="<?php echo e(route('admin.courses.show', $course)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">View</a>
                            <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Edit</a>
                            <form method="POST" action="<?php echo e(route('admin.courses.destroy', $course)); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this course?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 1.5rem;">
            <?php echo e($courses->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 3rem; color: #64748b;">
            <h4>No courses found</h4>
            <p>Get started by creating your first course.</p>
            <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary" style="margin-top: 1rem;">Create First Course</a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>