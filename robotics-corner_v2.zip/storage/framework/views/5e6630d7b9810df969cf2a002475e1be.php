

<?php $__env->startSection('title', 'Logo & Favicon Manager'); ?>
<?php $__env->startSection('page-title', 'Logo & Favicon Manager'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 style="margin: 0; color: #1e293b;">Upload Logo & Favicon</h2>
    </div>

    <?php if(session('success')): ?>
        <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Upload Forms -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
        <!-- Logo Upload -->
        <div style="border: 2px dashed #d1d5db; border-radius: 12px; padding: 2rem; text-align: center; background: #f9fafb;">
            <h3 style="color: #1e293b; margin-bottom: 1rem;">Upload Logo</h3>
            <?php if($logo): ?>
                <div style="margin-bottom: 1rem;">
                    <img src="<?php echo e($logo->value); ?>" alt="Current Logo" style="max-width: 200px; max-height: 100px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <p style="font-size: 0.875rem; color: #64748b; margin-top: 0.5rem;">Current Logo</p>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.file-manager.upload')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="type" value="logo">
                <input type="file" name="file" accept="image/*" required style="margin-bottom: 1rem;">
                <button type="submit" class="btn btn-primary" style="width: 100%;">Upload Logo</button>
            </form>
            <p style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem;">JPEG, PNG, JPG, GIF, SVG (Max 2MB)</p>
        </div>

        <!-- Favicon Upload -->
        <div style="border: 2px dashed #d1d5db; border-radius: 12px; padding: 2rem; text-align: center; background: #f9fafb;">
            <h3 style="color: #1e293b; margin-bottom: 1rem;">Upload Favicon</h3>
            <?php if($favicon): ?>
                <div style="margin-bottom: 1rem;">
                    <img src="<?php echo e($favicon->value); ?>" alt="Current Favicon" style="max-width: 64px; max-height: 64px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <p style="font-size: 0.875rem; color: #64748b; margin-top: 0.5rem;">Current Favicon</p>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.file-manager.upload')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="type" value="favicon">
                <input type="file" name="file" accept="image/*" required style="margin-bottom: 1rem;">
                <button type="submit" class="btn btn-primary" style="width: 100%;">Upload Favicon</button>
            </form>
            <p style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem;">ICO, PNG, JPG (Max 2MB)</p>
        </div>
    </div>

    <!-- Current Files -->
    <div>
        <h3 style="color: #1e293b; margin-bottom: 1rem;">Current Files</h3>
        <?php if(count($files) > 0): ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem;">
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem; text-align: center; background: white;">
                    <img src="<?php echo e($file['url']); ?>" alt="File preview" style="max-width: 100px; max-height: 100px; margin-bottom: 0.5rem; border-radius: 4px;">
                    <p style="font-size: 0.875rem; color: #6b7280; margin: 0.5rem 0;"><?php echo e($file['name']); ?></p>
                    <form method="POST" action="<?php echo e(route('admin.file-manager.delete')); ?>" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="file" value="<?php echo e($file['name']); ?>">
                        <button type="submit" onclick="return confirm('Are you sure you want to delete this file?')" 
                                style="background: #dc2626; color: white; border: none; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.875rem;">
                            Delete
                        </button>
                    </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p style="color: #6b7280; text-align: center; padding: 2rem;">No files uploaded yet.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/file-manager/index.blade.php ENDPATH**/ ?>