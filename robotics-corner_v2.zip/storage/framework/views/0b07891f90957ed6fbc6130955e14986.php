<?php $__env->startSection('title', 'Courses - Robotics Corner'); ?>
<?php $__env->startSection('description', 'Explore our comprehensive courses in robotics, embedded systems, and software engineering.'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero compact">
    <div class="container">
        <h1 class="section-title">Our Courses</h1>
        <p class="section-subtitle">Comprehensive programs designed to advance your technical career</p>
    </div>
</section>

<section class="section courses-section">
    <div class="container">
        <div class="courses-grid">
            
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="course-card reveal">
                <h3 class="course-title"><?php echo e($course['title']); ?></h3>
                <p class="course-description"><?php echo e($course['description']); ?></p>
                
                <div class="course-meta">
                    <span class="meta-item">⏱️ <?php echo e($course['duration']); ?></span>
                    <span class="meta-item">💰 <?php echo e($course['price']); ?></span>
                </div>
                
                <div class="course-topics">
                    <h4>What You'll Learn:</h4>
                    <?php $__currentLoopData = $course['topics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="topic-item">• <?php echo e($topic); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <div class="course-footer">
                    <div class="course-price"><?php echo e($course['price']); ?></div>
                    <div class="course-actions">
                        <a href="<?php echo e(route('courses.show', $course['id'])); ?>" class="btn-outline">Details</a>
                        <a href="<?php echo e(route('enroll')); ?>" class="btn-primary">Enrollment</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/courses/index.blade.php ENDPATH**/ ?>