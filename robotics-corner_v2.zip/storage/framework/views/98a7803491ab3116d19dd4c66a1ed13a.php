<!-- FAQ Section -->
<section class="faq-section">
    <div class="container">
        <?php if(isset($section->content['title'])): ?>
            <div class="section-header">
                <h2 class="section-title"><?php echo e($section->content['title']); ?></h2>
            </div>
        <?php endif; ?>
        
        <?php if(isset($section->content['faqs']) && is_array($section->content['faqs'])): ?>
            <div class="faq-list">
                <?php $__currentLoopData = $section->content['faqs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(<?php echo e($index); ?>)">
                            <h3><?php echo e($faq['question'] ?? 'Question'); ?></h3>
                            <span class="faq-toggle">+</span>
                        </div>
                        <div class="faq-answer" id="faq-answer-<?php echo e($index); ?>">
                            <p><?php echo e($faq['answer'] ?? 'Answer'); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
function toggleFaq(index) {
    const answer = document.getElementById('faq-answer-' + index);
    const toggle = answer.previousElementSibling.querySelector('.faq-toggle');
    
    if (answer.style.display === 'block') {
        answer.style.display = 'none';
        toggle.textContent = '+';
    } else {
        answer.style.display = 'block';
        toggle.textContent = '-';
    }
}
</script>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/sections/faq.blade.php ENDPATH**/ ?>