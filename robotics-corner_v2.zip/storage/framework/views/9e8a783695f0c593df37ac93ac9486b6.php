<?php
    $siteTitle = 'Robotics Corner';
    $siteTagline = 'Professional robotics and software engineering training programs';
    
    // Check for favicon files in public folder in order of preference
    $siteFavicon = '/images/favicon.ico'; // default
    if (file_exists(public_path('favicon.ico'))) {
        $siteFavicon = '/images/favicon.ico';
    } elseif (file_exists(public_path('favicon.png'))) {
        $siteFavicon = '/images/favicon.png';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', $siteTitle); ?></title>
    <meta name="color-scheme" content="light dark">
    <meta name="description" content="<?php echo $__env->yieldContent('description', $siteTagline); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e($siteFavicon); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <main id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/components/layout.blade.php ENDPATH**/ ?>