

<?php $__env->startSection('title', 'Pages Management'); ?>
<?php $__env->startSection('page-title', 'Pages Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h3 style="margin: 0; color: #1e293b;">All Pages</h3>
        <a href="<?php echo e(route('admin.pages.create')); ?>" class="btn btn-primary">+ Add New Page</a>
    </div>

    <!-- Filters -->
    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
        <form method="GET" action="<?php echo e(route('admin.pages.index')); ?>" style="display: flex; gap: 1rem; align-items: center;">
            <select name="type" class="form-input" style="width: auto; padding: 0.5rem;">
                <option value="">All Types</option>
                <option value="special" <?php echo e(request('type') === 'special' ? 'selected' : ''); ?>>Special</option>
                <option value="dynamic" <?php echo e(request('type') === 'dynamic' ? 'selected' : ''); ?>>Dynamic</option>
            </select>
            
            <select name="status" class="form-input" style="width: auto; padding: 0.5rem;">
                <option value="">All Status</option>
                <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
            </select>
            
            <button type="submit" class="btn btn-secondary">Filter</button>
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-secondary">Clear</a>
        </form>
    </div>

    <?php if($pages->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Slug</th>
                    <th>Page Type</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <strong><?php echo e($page->title); ?></strong>
                    </td>
                    <td>
                        <code style="background: #f1f5f9; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.9rem;"><?php echo e($page->slug); ?></code>
                    </td>
                    <td>
                        <span class="status-badge <?php echo e($page->is_special ? 'status-completed' : 'status-pending'); ?>">
                            <?php echo e($page->page_type); ?>

                        </span>
                    </td>
                    <td>
                        <span class="status-badge <?php echo e($page->is_active ? 'status-approved' : 'status-rejected'); ?>">
                            <?php echo e($page->status); ?>

                        </span>
                    </td>
                    <td><?php echo e($page->created_at->format('M d, Y')); ?></td>
                    <td>
                        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                            <a href="<?php echo e(route('admin.pages.builder', $page)); ?>" class="btn btn-primary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">🏗️ Build</a>
                            <a href="<?php echo e(route('admin.pages.show', $page)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">View</a>
                            <a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Edit</a>
                            <?php if(!$page->is_special): ?>
                                <form method="POST" action="<?php echo e(route('admin.pages.destroy', $page)); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this page?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div style="margin-top: 1.5rem;">
            <?php echo e($pages->appends(request()->query())->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 3rem; color: #64748b;">
            <p style="font-size: 1.1rem; margin-bottom: 1rem;">No pages found.</p>
            <a href="<?php echo e(route('admin.pages.create')); ?>" class="btn btn-primary">Create Your First Page</a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>