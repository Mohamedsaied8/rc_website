<?php
    $siteTitle = 'Robotics Corner';
    
    // Check for logo files in public/images in order of preference
    $siteLogo = '/images/logo.png'; // default
    if (file_exists(public_path('images/logo.png'))) {
        $siteLogo = '/images/logo.png';
    } elseif (file_exists(public_path('images/logo.jpg'))) {
        $siteLogo = '/images/logo.jpg';
    } elseif (file_exists(public_path('images/logo.svg'))) {
        $siteLogo = '/images/logo.svg';
    }
?>

<header class="header">
    <nav class="nav">
        <a href="<?php echo e(route('home')); ?>" class="logo">
            <img src="<?php echo e($siteLogo); ?>" alt="<?php echo e($siteTitle); ?>" class="logo-img" style="height: 40px; margin-right: 10px;">
            <!-- <?php echo e($siteTitle); ?> -->
        </a>
        <ul class="nav-links" id="nav-links">
            <li><a href="<?php echo e(route('programs.index')); ?>">Programs</a></li>
            <li><a href="<?php echo e(route('courses.index')); ?>">Courses</a></li>
            <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
        </ul>
        <div class="nav-actions">
            <a href="<?php echo e(route('courses.index')); ?>#enroll" class="btn-primary">Enroll Now</a>
            <button class="theme-toggle" aria-label="Toggle theme">🌙</button>
            <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="Toggle menu">☰</button>
        </div>
    </nav>
</header>

<!-- Skip Link for Accessibility -->
<a href="#main" class="skip-link">Skip to main content</a>

<!-- Scroll Progress Bar -->
<div class="scroll-progress"></div>

<!-- Back to Top Button -->
<button class="back-to-top" aria-label="Back to top">↑</button>
<?php /**PATH D:\Intelligence Stream Labs\Robotics Cornor System\robotic_corner\robotics-corner\resources\views/components/header.blade.php ENDPATH**/ ?>