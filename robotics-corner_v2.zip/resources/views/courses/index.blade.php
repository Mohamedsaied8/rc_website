@extends('components.layout')

@section('title', 'Courses - Robotics Corner')
@section('description', 'Explore our comprehensive courses in robotics, embedded systems, and software engineering.')

@section('content')
<section class="hero compact">
    <div class="container">
        <h1 class="section-title">Our Courses</h1>
        <p class="section-subtitle">Comprehensive programs designed to advance your technical career</p>
    </div>
</section>

<section class="section courses-section">
    <div class="container">
        <div class="courses-grid">
            
            @foreach($courses as $course)
            <div class="course-card reveal">
                <h3 class="course-title">{{ $course['title'] }}</h3>
                <p class="course-description">{{ $course['description'] }}</p>
                
                <div class="course-meta">
                    <span class="meta-item">⏱️ {{ $course['duration'] }}</span>
                    <span class="meta-item">💰 {{ $course['price'] }}</span>
                </div>
                
                <div class="course-topics">
                    <h4>What You'll Learn:</h4>
                    @foreach($course['topics'] as $topic)
                    <div class="topic-item">• {{ $topic }}</div>
                    @endforeach
                </div>
                
                <div class="course-footer">
                    <div class="course-price">{{ $course['price'] }}</div>
                    <div class="course-actions">
                        <a href="{{ route('courses.show', $course['id']) }}" class="btn-outline">Details</a>
                        <a href="{{ route('enroll') }}" class="btn-primary">Enrollment</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endsection
