@extends('components.layout')

@section('title', $course['title'] . ' - Robotics Corner')
@section('description', $course['description'])

@section('content')
<section class="hero">
    <div class="container">
        <h1 class="section-title">{{ $course['title'] }}</h1>
        <p class="section-subtitle">{{ $course['description'] }}</p>
        
        @if(isset($course['video']))
        <div class="course-video" style="margin-top: 2rem; max-width: 800px;">
            <iframe width="100%" height="400" style="min-height: 300px; border: 0; border-radius: 12px" src="{{ $course['video'] }}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        @endif
    </div>
</section>

<div class="container" style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; padding: 2rem 0;">
    <main class="panel" style="background: #fff; border: 1px solid #e2e8f0; border-radius: 18px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); padding: 1.5rem;">
        <h2 style="margin-bottom: 0.5rem">Overview</h2>
        <p class="subtitle" style="color: #64748b; margin-bottom: 1.5rem;">{{ $course['overview'] }}</p>
        
        <h3 style="margin: 1rem 0 0.5rem">What You'll Learn</h3>
        <ul class="list" style="display: grid; gap: 0.5rem; color: #475569;">
            @foreach($course['what_youll_learn'] as $item)
            <li>• {{ $item }}</li>
            @endforeach
        </ul>
        
        <h3 style="margin: 1.5rem 0 0.5rem">Projects</h3>
        <ul class="list" style="display: grid; gap: 0.5rem; color: #475569;">
            @foreach($course['projects'] as $project)
            <li>• {{ $project }}</li>
            @endforeach
        </ul>
        
        <h3 style="margin: 1.5rem 0 0.5rem">Highlights</h3>
        <ul class="list" style="display: grid; gap: 0.5rem; color: #475569;">
            @foreach($course['highlights'] as $highlight)
            <li>• {{ $highlight }}</li>
            @endforeach
        </ul>
    </main>
    
    <aside class="panel" style="background: #fff; border: 1px solid #e2e8f0; border-radius: 18px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); padding: 1.5rem;">
        <h3>Course Details</h3>
        <div class="list" style="display: grid; gap: 0.5rem; color: #475569; margin: 1rem 0;">
            <div>• Duration: {{ $course['duration'] }}</div>
            <div>• Price: {{ $course['price'] }}</div>
            <div>• Format: Online/Onsite</div>
            <div>• Certificate included</div>
        </div>
        @if(isset($course['associated_program']))
            <a href="{{ route('enroll', ['program' => $course['associated_program']['slug']]) }}" class="btn" style="display: inline-block; margin-top: 1rem; padding: 0.8rem 1.2rem; border-radius: 12px; font-weight: 700; background: #2dd4bf; color: #0b1220; text-decoration: none;">Enroll in {{ $course['associated_program']['title'] }}</a>
        @else
            <a href="{{ route('enroll') }}" class="btn" style="display: inline-block; margin-top: 1rem; padding: 0.8rem 1.2rem; border-radius: 12px; font-weight: 700; background: #2dd4bf; color: #0b1220; text-decoration: none;">View Programs</a>
        @endif
    </aside>
</div>

<style>
@media (max-width: 1000px) {
    .container {
        grid-template-columns: 1fr !important;
    }
}

body.dark .panel {
    background: #0f172a !important;
    border-color: #1f2937 !important;
    box-shadow: 0 6px 18px rgba(0,0,0,0.35) !important;
}

body.dark .list {
    color: #94a3b8 !important;
}

body.dark .subtitle {
    color: #94a3b8 !important;
}
</style>
@endsection
